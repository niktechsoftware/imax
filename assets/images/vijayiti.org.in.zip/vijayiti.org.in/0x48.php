<!-- #indonesiancodeparty #indonesianhackers #indonesiandefacer #opworld #worldpeace-->



<meta charset="utf-8">
<meta content="Hacked by FRK48" name="Author">
<meta content="Hacked by FRK48" name="description">
<meta content="Hacked by FRK48" name="Abstract">
<meta content="Hacked by FRK48" name="keywords">
<meta content="Hacked by FRK48" name="author">
<meta content="all, index, follow" name="robots">
<meta content="all, index, follow" name="googlebot">
<meta content="all, index, follow" name="spiders">
<meta property="og:title" content="FRK48 was here Babyyy~">
<meta name="description" content="Indonesian Code Party">

<meta property="og:image" content="https://wallpaperstream.com/wallpapers/thumbnails/cute-panda/Cute-Panda-with-White-Background-Art_thumb2x.jpg">
<meta property="og:image:width " content="500">
<meta property="og:image:height" content="250">

<meta name="distribution" content="global"/><link href="http://fonts.googleapis.com/css?family=Share+Tech+Mono" rel="stylesheet" type="text/css">
<title> Hacked by FRK48 - Indonesian Code Party</title>

<!--[if IE]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<style>
body{
background:white;
}
#och{
font-family:Courier;
color:white;
position:absolute;
left:0;
left:0;
right:0;
top:10%;
}
#ochh{
font-size:25px;
font-weight:bold;
}
hr {
width:250px;
}
a{
color:black;
text-decoration:none
}
a.hover{
color:white;
}
</style>
</head>
<body>
<body onload="play()">
<center>
<body oncontextmenu='return false;' onkeydown='return false;' onmousedown='return false;'>
<div id='och' align="center">
<div id='ochh'>

<b><font color='white' size="8" style="text-shadow: black 0 0 10px;" face="Share Tech Mono">Hacked by FRK48</font></b>
<br>
<img src="https://thumbs.gfycat.com/NiceContentBarasinga-size_restricted.gif" width="340" height="240"/>
<br>
<font color='black' size="5" face="Share Tech Mono"><b> "We Can Party In Your System" </b></font>
<br>
<br>
</font>
<font color='red' size="6" face="Share Tech Mono"><b><u> Indonesian Code Party </u></b></font>
<br>
<font color='black' size="4" face="Share Tech Mono"><b>ZeynnymouZ - ./BlaDDzeRR - UnknownYmouz - -DenJaka- - Consept_IXI - ./Coco - 0x1999 - Lock-Down - ./UnIX - ./L1ght_r00t - ./PionHitam - Mr.Vendetta_404 - gunz_berry - ./sn00py - HIRUKO-09 - p0r7s - Yukiteru404 - S4bun - Astra - L4663r666h05t - ZakirDotID - D4rkside - <font color="red"><b>FRK48</b></font>
<br>
<br>
<font color='red' size="5" face="Share Tech Mono"><b>
<u>Thanks to: </u></b></font><br> <marquee width="60%" behavior="alternate" scrollamount="2"><font color='black' size="4" face="Share Tech Mono"><b>### K4MVR3T717 - 17_PersonNotFound - Mr.Trouble5hooting - AL-VRI - ./Cyber00t - Con7ext - AZZATSSINS - M3sicth and Indonesian Defacer ###</b></font></marquee>
<br>
<br>
</font>

<audio autoplay>	<source src="https://3.top4top.net/m_14597m0jq1.mp3"type='audio/mpeg'> 


<!-- #indonesiancodeparty #indonesianhackers #indonesiandefacer #opworld #worldpeace -->