<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Mirrored from vijaypiti.org.in/ by HTTrack Website Copier/3.x [XR&CO'2013], Fri, 20 Dec 2019 06:54:08 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="google-site-verification" content="jCdqg5myFNL7cZs-APyYzWUyWO4wNDnukhsFQqmZ1x0" />
<title>Vijay Private Industrial Training Institute, Ghazipur</title>
<meta name="description" content= "Vijay Private Industrial Training Institute,Ghazipur, U.P., India" />
 <meta name="keywords" content= "Vijay Private Industrial Training Institute, Ghazipur,  U.P., India, vijaypiti.org.in, iti college in Ballia,  college in Ballia" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<link href="images/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
-->
</style>
<link rel="stylesheet" type="text/css" href="images/ddsmoothmenu.css">
<link rel="stylesheet" type="text/css" href="images/ddsmoothmenu-v.css">

<script type="text/javascript" src="images/jquery.js"></script>
<script type="text/javascript" src="images/ddsmoothmenu.js">

/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>

<body>

<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody><tr>
    <td align="center"><table align="center" border="0" cellpadding="0" cellspacing="0" width="1004">
      <tbody><tr>
        <td align="center"><table align="center" border="0" cellpadding="0" cellspacing="0" width="1004">
          <tbody><tr>
            <td><table border="0" cellpadding="0" cellspacing="0" width="1004">
              <tbody><tr>
                <td width="152"><img src="images/index_01.jpg" alt="" height="140" width="152"></td>
                <td valign="top" width="852"><table border="0" cellpadding="0" cellspacing="0" width="852">
                  <tbody><tr>
                    <td><table border="0" cellpadding="0" cellspacing="0" width="852">
                      <tbody><tr>
                        <td width="607"><img src="images/index_02.jpg" alt="" height="112" width="607"></td>
                        <td valign="top" width="245"><table border="0" cellpadding="0" cellspacing="0" width="245">
                          <tbody><tr>
                            <td><table align="center" border="0" cellpadding="0" cellspacing="0" width="245">
                              <tbody><tr>
                                <td width="82"><a href="#"><img src="images/index_03.jpg" alt="" border="0" height="37" width="82"></a></td>
                                <td width="76"><a href="ncvt_result.html"><img src="images/index_04.jpg" alt="" border="0" height="37" width="76"></a></td>
                                <td width="87"><a href="contactus.html"><img src="images/index_05.jpg" alt="" border="0" height="37" width="87"></a></td>
                              </tr>
                            </tbody></table></td>
                          </tr>
                          <tr>
                            <td class="title2" align="left" background="images/index_06.jpg" height="75" valign="middle">                              College Code: PITI2804<br> 
                              Affiliated To Govt. of India & Uttar Pradesh</td>
                          </tr>
                        </tbody></table></td>
                      </tr>
                    </tbody></table></td>
                  </tr>
                  <tr>
                    <td class="menu" bgcolor="#1B71A0" height="28"><table border="0" cellpadding="0" cellspacing="0" width="852">
                      <tbody><tr>
                        <td bgcolor="#1B71A0" width="2"></td>
                        <td align="left" bgcolor="#1B71A0" width="838"> <div id="smoothmenu1" class="ddsmoothmenu">
<ul>
<li class="font"><a href="index-2.html">HOME</a></li>
<li class="font"><a href="#">INTRODUCTION</a>
  <ul>
  <li class="font"><a href="#">About Institute</a></li>
  <li class="font"><a href="#">Mission &amp; Objectives</a></li>
  <li class="font"><a href="#">History</a></li>
  <li class="font"><a href="#">Managing Society</a></li>
 <li class="font"><a href="#">Manager Message</a></li>
 <li class="font"><a href="#">Principal Message</a></li>

  <li class="font"><a href="#">Chairman and Members</a></li>
  </ul>
</li>
<li class="font"><a href="#">ADMISSION CRITERIA</a>
</li>
<li class="font"><a href="#">FACULTY</a>
  <ul>
  <li class="font"><a href="#">Teaching Staff</a></li>
  <li class="font"><a href="#">Administrative Staff</a>
  </li>
 		</ul>
  </li>
  
  <li class="font"><a href="#">INFRASTRUCTURE</a></li>
<li class="font"><a href="#">QUALITY MONITORING</a>

  <ul>
    <li class="font"><a href="#">Attendance</a>
    <ul>
    		<li><a href="#">Attendance of Instructor</a></li>
    		<li><a href="#">Attendance of Trainees</a></li>
 		</ul></li>
        <li class="font"><a href="#">Progress Card</a>
    <ul>
    		<li><a href="#">Trade-I</a></li>
    		<li><a href="#">Trade-II</a></li>
 		</ul></li>
      
      </ul>
      </li>
      
      <li class="font"><a href="#">PLACEMENT</a>

        <ul>
    <li class="font"><a href="#" >Details of Placement Cell</a></li>
      <li class="font"><a href="#">Placement Record of the Trainees</a></li>
      </ul>
      </li>
</ul>
<br style="clear: left">
</div></td>
                      </tr>
                    </tbody></table></td>
                  </tr>
                </tbody></table></td>
              </tr>
            </tbody></table></td>
          </tr>
          <tr>
            <td height="5"><img src="images/index_20.jpg" alt="" height="5" width="1004"></td>
          </tr>
          <tr>
            <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="1004">
              <tbody><tr>
                <td width="16"><img src="images/index_21.jpg" alt="" height="229" width="16"></td>
                <td width="776"><iframe src="images/banner.html" allowtransparency="true" frameborder="0" scrolling="no" style="height:229px; width:776px;"></iframe></td>
                <td valign="top" width="198"><table border="0" cellpadding="0" cellspacing="0" width="198">
                  <tbody><tr>
                    <td><a href="#"><img src="images/index_23.jpg" alt="" border="0" height="67" width="198"></a></td>
                  </tr>
                  <tr>
                    <td><a href="#"><img src="images/index_25.jpg" alt="" border="0" height="52" width="198"></a></td>
                  </tr>
                  <tr>
                    <td><a href="syllabus.html"><img src="images/index_26.jpg" alt="" border="0" height="53" width="198"></a></td>
                  </tr>
                  <tr>
                    <td><a href="ncvt_result.html"><img src="images/index_27.jpg" alt="" border="0" height="57" width="198"></a></td>
                  </tr>
                </tbody></table></td>
                <td width="14"><img src="images/index_24.jpg" alt="" height="229" width="14"></td>
              </tr>
            </tbody></table></td>
          </tr>
          <tr>
            <td align="right" bgcolor="#F1F5F8" height="14"><img src="images/index_29.jpg" alt="" height="14" width="147"></td>
          </tr>
          <tr>          </tr>
          <tr>
            <td><table border="0" cellpadding="0" cellspacing="0" width="1004">
              <tbody><tr>
                <td bgcolor="#F1F5F8" height="348" width="16"></td>
                <td bgcolor="#F1F5F8" valign="top" width="766"><table border="0" cellpadding="0" cellspacing="0" width="766">
                  <tbody><tr>
				  
                    <td align="center" bgcolor="#FFFFFF" height="85" valign="middle"><a href="ncvt_result.html" target="_blank"><img src="images/quote.png" height="66" width="747"></a></td>
                  </tr>
                  <tr>
                    <td bgcolor="#F1F5F8" height="6"></td>
                  </tr>
                  <tr>
                    <td bgcolor="#F1F5F8" height="30"></td>
                  </tr>
                  <tr>
                    <td bgcolor="#F1F5F8" height="6"></td>
                  </tr>
                  <tr>
                    <td bgcolor="#FFFFFF" height="6"></td>
                  </tr>
                  <tr bgcolor="#FFFFFF">
                    <td height="6"></td>
                  </tr>
                  <tr>
                    <td align="center" bgcolor="#FFFFFF" valign="middle"><table border="0" cellpadding="0" cellspacing="0" height="236" width="766">
                      <tbody><tr>
                        <td bgcolor="#FFFFFF" height="10" width="10"></td>
                        <td bgcolor="#FFFFFF" height="5"></td>
                      </tr>
                      <tr>
                        <td></td>
                        <td>
<table border="0" cellpadding="0" cellspacing="0" width="756">
                            <tbody><tr>
                               <td width="90" align="left" valign="top"><img src="images/short_home.jpg" ></td>
                              <td valign="top" width="198"><table border="0" cellpadding="0" cellspacing="0" width="279">
                                  <tbody><tr>
                                    <td height="20"><a href="#" class="title1">Short History</a></td>
                                  </tr>
                                  <tr>
                                    <td><table border="0" cellpadding="0" cellspacing="0" width="279">
                                        <tbody><tr>
                                          <td class="heading" align="justify" style="padding-right:5px;">Vijay Private Industrial Training Institute was established in 2015 with an objective of imparting skills in various vocational trades to meet the skilled manpower</span> ...</td>
                                        </tr>
                                        </tbody></table></td>
                                  </tr>
                                  <tr>
                                    <td class="more" align="right" height="14"><a href="short_history.html" class="more">More Info</a></td>
                                  </tr>
                              </tbody></table></td>
                              <td width="90" align="left" valign="top"><img src="images/2.jpg" ></td>
                              <td valign="top" width="279"><table border="0" cellpadding="0" cellspacing="0" width="279">
                                  <tbody><tr align="left">
                                    <td height="20"><a href="#" class="title1">प्रबन्धक  का संदेश</a></td>
                                  </tr>
                                   <tr>
                                    <td class="heading" align="justify" style="padding-right:5px;">प्रगतिशील युग में तकनीकी प्रशिक्षण का योगदान
आप के सामाजिक परिवेश में शिक्षा की प्रसंगिता पर विचार करे तो यह बात स्पस्ट हो जाती है कि प्राचीन समय में ....</td>
                                  </tr>
                                  <tr>
                                    <td class="more" align="right" height="18"><a href="manager_msg.html" class="more">More MSG</a></td>
                                  </tr>
                              </tbody></table></td>
                            </tr>
                        </tbody></table>
                        
                        <table border="0" cellpadding="0" cellspacing="0" width="756">
                            <tbody><tr>
                               <td width="90" align="left" valign="top"><img src="images/principal_home.jpg" ></td>
                              <td valign="top" width="198"><table border="0" cellpadding="0" cellspacing="0" width="279">
                                  <tbody><tr>
                                    <td height="20"><a href="#" class="title1">Principal's Message</a></td>
                                  </tr>
                                  <tr>
                                    <td><table border="0" cellpadding="0" cellspacing="0" width="279">
                                        <tbody><tr>
                                           <td class="heading" align="justify" style="padding-right:5px;">Vijay Private Industrial Training institute, Ghazipur, U.P., India is a sure success destination for trainees who want to excel in the present industrial ...</td>
                                        </tr>
                                        </tbody></table></td>
                                  </tr>
                                  <tr>
                                    <td class="more" align="right" height="14"><a href="principal_msg.html" class="more">More Info</a></td>
                                  </tr>
                              </tbody></table></td>
                              <td width="90" align="left" valign="top"><img src="images/president_home.jpg" ></td>
                              <td valign="top" width="279"><table border="0" cellpadding="0" cellspacing="0" width="279">
                                  <tbody><tr align="left">
                                    <td height="20"><a href="#" class="title1">Courses Offered</a></td>
                                  </tr>
                                   <tr>
                                    <td class="heading" align="justify" style="padding-right:5px;">Fitter &amp; Electrician<br /><br />
                                    Fitter (63 Seats Total)<br />
                                    Electrician (63 Seats Total)<br /></td>
                                  </tr>
                                  <tr>
                                    <td class="more" align="right" height="18"><a href="admission_criteria.html" class="more">More MSG</a></td>
                                  </tr>
                              </tbody></table></td>
                            </tr>
                        </tbody></table>
                                                </td>
                      </tr>
                      <tr>
                        <td></td>
                        <td align="center" height="25" valign="top"><img src="images/index_69.jpg" alt="" height="17" width="756"></td>
                      </tr>
                      <tr>
                        <td></td>
                        <td><table border="0" cellpadding="0" cellspacing="0" width="756">
                            <tbody><tr>
                              <td align="left" valign="top" width="179"><img src="images/3.jpg" height="83" width="179"></td>
                              <td valign="top" width="198"><table border="0" cellpadding="0" cellspacing="0" width="198">
                                  <tbody><tr>
                                    <td align="left" height="20"><a href="#"><img src="images/index_71.jpg" alt="" border="0" height="13" width="123"></a></td>
                                  </tr>
                                  <tr>
                                    <td align="center" valign="middle"><table border="0" cellpadding="0" cellspacing="0" width="198">
                                        <tbody><tr>
                                          <td align="right" height="19" valign="bottom" width="25"><img src="images/index_44.jpg" alt="" height="16" width="12"></td>
                                          <td class="heading" align="left" height="16" valign="middle" width="172"><a href="#" class="heading">Placement</a></td>
                                        </tr>
                                        <tr>
                                          <td align="right" height="23" width="25"><img src="images/index_44.jpg" alt="" height="16" width="12"></td>
                                          <td class="heading" align="left" height="16" valign="middle" width="172"><a href="#" class="heading">Guidance &amp; Counselling</a></td>
                                        </tr>
                                        <tr>
                                          <td align="right" height="18" valign="bottom" width="25"><img src="images/index_44.jpg" alt="" height="16" width="12"></td>
                                          <td class="heading" align="left" height="18" valign="middle" width="172"><a href="#" class="heading">Skill Development</a></td>
                                        </tr>
                                    </tbody></table></td>
                                  </tr>
                                  <tr>
                                    <td class="more" align="right" height="18"><a href="#" class="more">More Info</a></td>
                                  </tr>
                              </tbody></table></td>
                              <td align="left" valign="top" width="179"><img src="images/infra1.jpg" height="83" width="175"></td>
                              <td valign="top" width="202"><table border="0" cellpadding="0" cellspacing="0" width="202">
                                  <tbody><tr>
                                    <td align="left" height="20"><a href="#"><img src="images/index_74.jpg" alt="" border="0" height="16" width="194"></a></td>
                                  </tr>
                                  <tr>
                                    <td><table border="0" cellpadding="0" cellspacing="0" width="198">
                                        <tbody><tr>
                                          <td align="right" valign="middle" width="25"><img src="images/index_44.jpg" alt="" height="16" width="12"></td>
                                          <td class="heading" align="left" height="16" valign="middle" width="173"><a href="#" class="heading">Academic Infrastructure</a></td>
                                        </tr>
                                        <tr>
                                          <td align="right" height="18" width="25"><img src="images/index_44.jpg" alt="" height="16" width="12"></td>
                                          <td class="heading" align="left" height="16" valign="middle" width="173"><a href="#" class="heading">Hostel</a></td>
                                        </tr>
                                        <tr>
                                          <td align="right" height="21" valign="middle" width="25"><img src="images/index_44.jpg" alt="" height="16" width="12"></td>
                                          <td class="heading" align="left" height="21" valign="middle" width="173"><a href="#" class="heading">Medical Facilities</a></td>
                                        </tr>
                                    </tbody></table></td>
                                  </tr>
                                  <tr>
                                    <td class="more" align="right" height="20" valign="middle"><a href="#" class="more">More Info</a></td>
                                  </tr>
                              </tbody></table></td>
                            </tr>
                        </tbody></table></td>
                      </tr>
                      <tr>
                        <td height="10"></td>
                        <td height="5"></td>
                      </tr>
                    </tbody></table></td>
                  </tr>
                </tbody></table></td>
                <td bgcolor="#F1F5F8" width="7"></td>
                <td bgcolor="#F1F5F8" valign="top" width="203"><table align="center" border="0" cellpadding="0" cellspacing="0" width="203">
                  <tbody>
                  
                   <tr><td align="center" valign="top"><a href="#" target="_blank"><img src="images/college_detail.jpg" border="0"></a></td></tr>
<tr><td align="left"> <ul class="other"><li>   
<a href="#">Photo-Gallery</a></a></li><li>   
<a href="#">
    Schemes running in the Institute</a></li><li>   
<a href="#">
    Trades Affiliated to NCVT and SCVT</a></li><li>   
<a href="#">
    Summary of Trades affiliated to NCVT</a></li><li>   
<a href="#">
    Summary of Trades affiliated to SCVT</a></li><li>   
<a href="#">
    Court Cases and Status</a></li><li>   
<a href="#">
    Electric Power Supply</a></li><li>   
<a href="#">
    Record of Trainees</a></li><li>   
<a href="#">
    Issue of certificate to Trainees</a></li><li>   
<a href="#">
    Visitors</a></li><li>   
<a href="#">
    Library</a></li><li>   
<a href="computer_lab.html">
    Computer Lab</a></li><li>   
<a href="#">
    Sports Facilities</a></li><li>   
<a href="#">
    Extra Curricular Activities</a></li><li>   
<a href="#">
    Details of Inspections</a></li><li>   
<a href="#">
    Courses</a></li><li>   
<a href="state_directorate.html">
    State Directorate</a></li><li>   
<a href="fund_status.html">
    Fund Status</a></li><li>   
<a href="dget_state_govt_form.html">
    DGET and State Government orders</a></li><li>   
<a href="feed_back.html">
    Feedback and suggestions</a></li></ul>
</td></tr><tr>
                    <td><img src="images/index_34.jpg" alt="" height="58" width="203"></td>
                  </tr>
                  <tr>
                    <td><table border="0" cellpadding="0" cellspacing="0" width="203">
                      <tbody>
                      
                      <tr>
                        <td background="images/index_54.jpg" height="110" width="12"></td>
                        <td bgcolor="#FDFCF7" height="110" valign="top" width="181"><iframe src="images/news.html" allowtransparency="true" frameborder="0" height="110" scrolling="No" width="100%"></iframe></td>
                        <td background="images/index_56.jpg" width="10"></td>
                      </tr>
                    </tbody></table></td>
                  </tr>
                 
                  <tr>
                    <td><img src="images/index_102.jpg" alt="" height="14" width="203"></td>
                  </tr>
                  
  
                </tbody></table></td>
                <td bgcolor="#F1F5F8" width="12"></td>
              </tr>
            </tbody></table></td>
          </tr>
          <tr>
            <td align="center" height="20" valign="middle"><table border="0" cellpadding="0" cellspacing="0" height="20" width="1004">
              <tbody><tr class="captionbg1">
                <td bgcolor="#F1F5F8" width="16">&nbsp;</td>
                <td class="title" align="left" valign="middle"><strong><a href="gallery.html" style="color:#FFF">Photo Gallery View More Click Here</a></strong></td>
                <td bgcolor="#F1F5F8" width="12">&nbsp;</td>
              </tr>
            </tbody></table></td>
          </tr>
          <tr>
            <td align="center" height="85" valign="bottom"><table border="0" cellpadding="0" cellspacing="0" width="1004">
              <tbody> <tr>
                <td height="67" width="16">&nbsp;</td>
                <td align="center" valign="middle"><script type="text/javascript">

//Specify the slider's width (in pixels)
var sliderwidth="976px"
//Specify the slider's height
var sliderheight="128px"
//Specify the slider's slide speed (larger is faster 1-10)
var slidespeed=2
//configure background color:
slidebgcolor=""

//Specify the slider's images
var leftrightslide=new Array()
var finalslide=''
leftrightslide[0]='<img src="images/gallery/1 (1)_s.jpg" border="0">'
leftrightslide[1]='<img src="images/gallery/1 (2)_s.jpg" border="0">'
leftrightslide[2]='<img src="images/gallery/1 (3)_s.jpg" border="0">'
leftrightslide[3]='<img src="images/gallery/1 (4)_s.jpg" border="0">'
leftrightslide[4]='<img src="images/gallery/1 (5)_s.jpg" border="0">'
leftrightslide[5]='<img src="images/gallery/1 (6)_s.jpg" border="0">'
leftrightslide[6]='<img src="images/gallery/1 (7)_s.jpg" border="0">'
leftrightslide[7]='<img src="images/gallery/1 (8)_s.jpg" border="0">'
//Specify gap between each image (use HTML):
var imagegap="&nbsp; &nbsp; &nbsp;"

//Specify pixels gap between each slideshow rotation (use integer):
var slideshowgap=0


////NO NEED TO EDIT BELOW THIS LINE////////////

var copyspeed=slidespeed
leftrightslide='<nobr>'+leftrightslide.join(imagegap)+'</nobr>'
var iedom=document.all||document.getElementById
if (iedom)
document.write('<span id="temp" style="visibility:hidden;position:absolute;top:-100px;left:-9000px">'+leftrightslide+'</span>')
var actualwidth=''
var cross_slide, ns_slide

function fillup(){
if (iedom){
cross_slide=document.getElementById? document.getElementById("test2") : document.all.test2
cross_slide2=document.getElementById? document.getElementById("test3") : document.all.test3
cross_slide.innerHTML=cross_slide2.innerHTML=leftrightslide
actualwidth=document.all? cross_slide.offsetWidth : document.getElementById("temp").offsetWidth
cross_slide2.style.left=actualwidth+slideshowgap+"px"
}
else if (document.layers){
ns_slide=document.ns_slidemenu.document.ns_slidemenu2
ns_slide2=document.ns_slidemenu.document.ns_slidemenu3
ns_slide.document.write(leftrightslide)
ns_slide.document.close()
actualwidth=ns_slide.document.width
ns_slide2.left=actualwidth+slideshowgap
ns_slide2.document.write(leftrightslide)
ns_slide2.document.close()
}
lefttime=setInterval("slideleft()",30)
}
window.onload=fillup

function slideleft(){
if (iedom){
if (parseInt(cross_slide.style.left)>(actualwidth*(-1)+8))
cross_slide.style.left=parseInt(cross_slide.style.left)-copyspeed+"px"
else
cross_slide.style.left=parseInt(cross_slide2.style.left)+actualwidth+slideshowgap+"px"

if (parseInt(cross_slide2.style.left)>(actualwidth*(-1)+8))
cross_slide2.style.left=parseInt(cross_slide2.style.left)-copyspeed+"px"
else
cross_slide2.style.left=parseInt(cross_slide.style.left)+actualwidth+slideshowgap+"px"

}
else if (document.layers){
if (ns_slide.left>(actualwidth*(-1)+8))
ns_slide.left-=copyspeed
else
ns_slide.left=ns_slide2.left+actualwidth+slideshowgap

if (ns_slide2.left>(actualwidth*(-1)+8))
ns_slide2.left-=copyspeed
else
ns_slide2.left=ns_slide.left+actualwidth+slideshowgap
}
}


if (iedom||document.layers){
with (document){
document.write('<table border="0" cellspacing="0" cellpadding="0"><td>')
if (iedom){
write('<div style="position:relative;width:'+sliderwidth+';height:'+sliderheight+';overflow:hidden">')
write('<div style="position:absolute;width:'+sliderwidth+';height:'+sliderheight+';background-color:'+slidebgcolor+'" onMouseover="copyspeed=0" onMouseout="copyspeed=slidespeed">')
write('<div id="test2" style="position:absolute;left:0px;top:0px"></div>')
write('<div id="test3" style="position:absolute;left:-1000px;top:0px"></div>')
write('</div></div>')
}
else if (document.layers){
write('<ilayer width='+sliderwidth+' height='+sliderheight+' name="ns_slidemenu" bgColor='+slidebgcolor+'>')
write('<layer name="ns_slidemenu2" left=0 top=0 onMouseover="copyspeed=0" onMouseout="copyspeed=slidespeed"></layer>')
write('<layer name="ns_slidemenu3" left=0 top=0 onMouseover="copyspeed=0" onMouseout="copyspeed=slidespeed"></layer>')
write('</ilayer>')
}
document.write('</td></table>')
}
}
                            </script></td>
                <td width="12">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="13"><img src="images/index_117.jpg" alt="" height="13" width="1004"></td>
          </tr>
          <tr>
            <td bgcolor="#fafafa" valign="top"><table border="0" cellpadding="0" cellspacing="0" width="1004">
              <tbody><tr>
                <td height="17" width="32"></td>
                <td height="17" valign="top" width="156"></td>
                <td height="17" valign="top" width="31"></td>
                <td height="17" valign="top" width="147"></td>
                <td height="17" valign="top" width="22"></td>
                <td height="17" valign="top" width="140"></td>
                <td height="17" valign="top" width="20"></td>
                <td height="17" valign="top" width="192"></td>
                <td height="17" valign="top" width="35"></td>
                <td height="17" valign="top" width="178"></td>
                <td width="26"></td>
              </tr>
              <tr>
                <td></td>
                <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="156">
                  <tbody><tr>
                    <td class="blue-content" align="left" height="30">Find Your Way</td>
                  </tr>
                  <tr>
                    <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="156">
                      <tbody><tr>
                        <td align="center" height="25" valign="middle" width="10"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="25" width="118"><a href="index-2.html" class="grey-content">Home</a></td>
                      </tr>
                      <tr>
                        <td align="center" height="25" valign="middle" width="10"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="25">
						<a class="grey-content" href="short_history.html">About Us</a></td>
                      </tr>
                      <tr>
                        <td align="center" height="25" valign="middle" width="10"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="25"><a class="grey-content" href="mission_objective.html">Mission &amp; Objectives</a></td>
                      </tr>
                      <tr>
                        <td align="center" height="25" valign="middle" width="10"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="25">
						<a class="grey-content" href="chairman_members.html">Managing Society</a></td>
                      </tr>
                    </tbody></table></td>
                  </tr>
                </tbody></table></td>
                <td valign="top"></td>
                <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="143">
                  <tbody><tr>
                    <td class="blue-content" align="left" height="30">Help &amp; Support</td>
                  </tr>
                  <tr>
                    <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="147">
                      <tbody><tr>
                        <td align="center" height="25" width="10"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="25" width="137"><a href="#" class="grey-content">Publications</a></td>
                      </tr>
                      <tr>
                        <td align="center" height="25"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="25"><a href="ncvt_result.html" class="grey-content">Downloads</a></td>
                      </tr>
                      <tr>
                        <td align="center" height="25"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="25"><a href="campus.html" class="grey-content">Campus</a></td>
                      </tr>
                      <tr>
                        <td align="center" height="25">&nbsp;</td>
                        <td class="grey-content" align="left" height="25"><a href="med.html" class="grey-content"></a></td>
                      </tr>
                      <tr>
                        <td align="center" height="25">&nbsp;</td>
                        <td class="grey-content" align="left" height="25"><a href="contactus.html" class="grey-content"></a></td>
                      </tr>
                    </tbody></table></td>
                  </tr>
                </tbody></table></td>
                <td valign="top"></td>
                <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="116">
                  <tbody><tr>
                    <td class="blue-content" align="left" height="30">Examination Related Details</td>
                  </tr>
                  <tr>
                    <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="248">
                      <tbody><tr>
                        <td align="center" height="25" width="8"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="25" width="240"><a href="images/Sample%20of%20OMR%20Sheet%20FOR%20THE%20EXAMINATION%20GOING%20TO%20HELD%20ON%20FEB%202014.pdf" target="_blank" class="grey-content">OMR SAMPLE SHEET FOR SEMESTER-I EXAM ON FEB 2014</a><a href="#" class="grey-content"></a></td>
                      </tr>
                      
                      
                      
                    </tbody></table></td>
                  </tr>
                </tbody></table></td>
                <td valign="top"></td>
                <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="192">
                  <tbody><tr>
                    <td class="blue-content" align="left" height="30">Academics</td>
                  </tr>
                  <tr>
                    <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="192">
                      <tbody><tr>
                        <td align="center" height="30" width="10"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="30"><a href="trade_affi_ncvt_svct.html" class="grey-content">Electrician (126 Seat Total)</a></td>
                      </tr>
                      <tr>
                        <td align="center" height="30"><img src="images/index_140.jpg" alt="" height="12" width="8"></td>
                        <td class="grey-content" align="left" height="30"><a href="trade_affi_ncvt_svct.html" class="grey-content">Fitter (126 Seat Total)</a></td>
                      </tr>
                      
                    </tbody></table></td>
                  </tr>
                </tbody></table></td>
                <td valign="top"></td>
                <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="172">
                  <tbody><tr>
                    <td class="blue-content" align="left" height="30">Contact Us</td>
                  </tr>
                  <tr>
                    <td valign="top"><table border="0" cellpadding="0" cellspacing="0" width="172">
                      <tbody><tr>
                        <td align="center" height="30" width="25"><img src="images/index_134.jpg" alt="" height="21" width="17"></td>
                        <td class="grey-content" align="left" height="30">+91-9415248152</td>
                      </tr>
                      <tr>
                        <td align="center" height="30" width="25"><img src="images/index_144.jpg" alt="" height="18" width="17"></td>
                        <td class="grey-content" align="left" height="30">
<a href="mailto:info@vijaypiti.org.in" target="_blank" class="grey-content">info@vijaypiti.org.in</a><br></td>
                      </tr>
                      <tr>
                        <td align="center" height="30"><img src="images/index_146.jpg" alt="" height="18" width="17"></td>
                        <td class="grey-content" align="left" height="30"><a href="contactus.html" class="grey-content">Google Maps</a></td>
                      </tr>
                      <tr>
                        <td align="center" height="30" width="25"><img src="images/index_144.jpg" alt="" height="18" width="17"></td>
                        <td class="grey-content" align="left" height="30"><a href="mailto:http://webmail.vijaypiti.org.in" target="_blank" class="grey-content">Webmail Login</a></td>
                      </tr>
                    </tbody></table></td>
                  </tr>
                </tbody></table></td>
                <td></td>
              </tr>
              <tr>
                <td height="10"></td>
                <td height="25" valign="top"></td>
                <td height="10" valign="top"></td>
                <td height="10" valign="top"></td>
                <td height="10" valign="top"></td>
                <td height="10" valign="top"></td>
                <td height="10" valign="top"></td>
                <td height="10" valign="top"></td>
                <td height="10" valign="top"></td>
                <td height="10" valign="top"></td>
                <td></td>
              </tr>
            </tbody></table></td>
          </tr>
          <tr>
            <td><img src="images/index_149.jpg" alt="" height="9" width="1004"></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF" height="55"><table border="0" cellpadding="0" cellspacing="0" width="1004">
              <tbody><tr>
                <td height="55" width="34">&nbsp;</td>
                <td class="footer" align="left" valign="middle" width="505">Copyright © <span class="blue-footer"> <script type="text/javascript">// <![CDATA[
	var currentTime = new Date()
	var year = currentTime.getFullYear()
	document.write(year)
// ]]></script>  | Vijay Private Industrial Training Institute, Ghazipur</span><br>
                  Designed by<a href="http://www.shiningsoftech.com/" target="_blank" class="footer"> Shining Softech</a>. </td>
                <td bgcolor="#FFFFFF" width="261"></td>
                <td class="grey-content" align="center" width="143"><strong>Follow us on </strong></td>
                <td align="left" width="60"><img src="images/index_154.jpg" alt="" height="55" width="38"></td>
              </tr>
            </tbody></table></td>
          </tr>
        </tbody></table></td>
      </tr>
    </tbody></table></td>
  </tr>
</tbody></table>


</body>
<!-- Mirrored from vijaypiti.org.in/ by HTTrack Website Copier/3.x [XR&CO'2013], Fri, 20 Dec 2019 06:55:09 GMT -->
</html>